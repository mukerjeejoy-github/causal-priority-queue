from .cpq import CausalPriorityQueue
